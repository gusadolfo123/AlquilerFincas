@extends('layouts.appAdmin')

@section('content')

    <div class="row-fluid">
        <header>
            <div class=" page-header text-center pt-4">
                <h1>Dashboard AlquilerFincas</h1>
            </div>
        </header>
    </div>

@endsection

