<?php $__env->startSection('content'); ?>

<h1 class=" page-header text-center mt-3">Formulario de Modificacion</h1>

<div class="container">        
    <div class="row pb-4 justify-content-center">                              
        <?php echo Form::model($cliente, ['route' => ['customers.update', $cliente->id], 'method' => 'PUT', 'class' => 'col-sm-12']); ?>

            <?php echo $__env->make('admin.customer.partial.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo Form::close(); ?>                
    </div>        
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.appAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>