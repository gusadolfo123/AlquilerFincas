<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
</head>

<body>

    <div class="container">
        <h1 class="page-header text-center mt-3 pt-2 pb-2 bg-success text-white ">Pre-Reserva</h1>
        <div class="row">
            <div class="col">
                Hola <i><?php echo e($demo->nomCompleto); ?></i>,
                <p>Te informamos que se ha realizado la pre-Reserva de la Finca: <?php echo e($demo->nomFinca); ?> con las siguientes
                    fechas: fecha desde <?php echo e($demo->fecDesde); ?> al <?php echo e($demo->fecHasta); ?></p>
            </div>
        </div>
        <div class="row">
            <table class="table table-hover text-center">
                <thead class="thead-dark">
                    <tr>
                        <th scope="col">Tipo Temporada</th>
                        <th scope="col">Precio por Noche</th>
                        <th scope="col">Nro de Noches</th> 
                        <th scope="col">Total</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th scope="row">Normal</th>
                        <td><?php echo e($demo->valNocheTempNormal); ?></td>
                        <td><?php echo e($demo->nroNochesN); ?></td>
                        <td><?php echo e($demo->totalNochesTempNormal); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Media</th>
                        <td><?php echo e($demo->valNocheTempMedia); ?></td>
                        <td><?php echo e($demo->nroNochesM); ?></td>
                        <td><?php echo e($demo->totalNochesTempMedia); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Alta</th>
                        <td><?php echo e($demo->valNocheTempAlta); ?></td>
                        <td><?php echo e($demo->nroNochesA); ?></td>
                        <td><?php echo e($demo->totalNochesTempAlta); ?></td>
                    </tr>
                    <tr>
                        <th scope="row"></th>
                        <td>Total</td>
                        <td><?php echo e($demo->nroNochesN + $demo->nroNochesM + $demo->nroNochesA); ?></td>
                        <td><?php echo e($demo->totalCotizacion); ?></td>
                    </tr>
                </tbody>
            </table>
        </div>

        <div class="row">
            <div class="col">
                Usuario:<?php echo e($demo->nomCompleto); ?>

                <br />
                Correo:<?php echo e($demo->correo); ?>

                <br />
                Telefono 1:<?php echo e($demo->telefono1); ?>

                <br />
                Telefono 2:<?php echo e($demo->telefono2); ?>


                <br /><br />
                Codigo de Reserva: <?php echo e($demo->nroReserva); ?>

            </div>
        </div>
       
    </div>


</body>

</html>