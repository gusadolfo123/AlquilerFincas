<?php $__env->startSection('content'); ?>

<h1 class=" page-header text-center mt-3">Formulario de Modificacion</h1>

<div class="container">        
        <div class="row pb-4 justify-content-center">
                <div class="row-fluid">
                        <a href="<?php echo e(url('farms/uploadImage', $finca->id )); ?>" class="btn btn-sm btn-primary">Agregar Fotos</a>
                </div>                
                <div class="row text-center bg-dark pb-4 ml-1 mr-1 mt-3" id="imagePanel">
                        <?php $__currentLoopData = $finca->fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-2" id="img-<?php echo e($foto->id); ?>">
                                        <a class="example-image-link thumbnail" href="<?php echo e($foto->archivo); ?>" data-lightbox="example-set" data-title="Click the right half of the image to move forward.">
                                                <div class="card bg-dark text-success mt-4">
                                                        <img class="card-img" src="<?php echo e($foto->archivo); ?>" alt="Card image">
                                                </div>  
                                        </a>    
                                        <div class="row-fluid bg-light">
                                                Eliminar
                                                <button type="button" class="close bg-light" data-dismiss="alert" aria-label="Close">
                                                        <span aria-hidden="true" onclick="eliminarImagen(<?php echo e($foto->id); ?>, '<?php echo e(route('farms.deleteImage')); ?>', 'img-<?php echo e($foto->id); ?>');" class=" mr-1 ml-1">&times;</span>
                                                </button>  
                                        </div>
                                                                                        
                                </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <?php echo Form::model($finca, ['route' => ['farms.update', $finca->id], 'method' => 'PUT', 'files' => true]); ?>


                        <?php echo $__env->make('admin.farm.partial.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <?php echo Form::close(); ?>      
                
                
        </div>        
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.appAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>