<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-12 my-2">
            <div class="card">
                <div class="card-header bg-success text-light">                    
                    <a href="<?php echo e(route('farms.edit', $finca->id)); ?>" class="btn btn-primary">Modificar</a>             
                    Detalle Finca: <?php echo e($finca->nombre); ?>

                </div>
                <div class="card-body">
                    <h5 class="card-title">Informacion General</h5>

                    <div class="row justify-content-start">
                        <div class="col-10">
                            <div class="row">
                                <div class="col-12 col-sm-4">
                                    <label class="mb-0" for="exampleInputEmail1">Direccion</label>                        
                                    <small id="emailHelp" class="form-text text-muted mt-0"><?php echo e($finca->direccion); ?></small>
                                </div>
                                <div class="col-12 col-sm-4">
                                    <label class="mb-0" for="exampleInputEmail1">Departamento</label>                        
                                    <small id="emailHelp" class="form-text text-muted mt-0"><?php echo e($finca->departamento->descripcion); ?></small>
                                </div>    
                                <div class="col-12 col-sm-4">
                                    <label class="mb-0" for="exampleInputEmail1">Via</label>                        
                                    <small id="emailHelp" class="form-text text-muted mt-0"><?php echo e($finca->via->descripcion); ?></small>
                                </div>                            
                            </div>                                                                                    
                        </div>                        
                    </div>                    
                    
                    <div class="row pt-4">
                        <div class="col-12 col-sm-4">
                            <label class="mb-0" for="exampleInputEmail1">Precio Temporada Baja</label>                        
                            <small id="emailHelp" class="form-text text-muted mt-0">$ <?php echo e(number_format($finca->precio_Tbaja, 0)); ?></small>
                        </div>
                        <div class="col-12 col-sm-4">
                            <label class="mb-0" for="exampleInputEmail1">Precio Temporada Media</label>                        
                            <small id="emailHelp" class="form-text text-muted mt-0">$ <?php echo e(number_format($finca->precio_Tmedia, 0)); ?></small>
                        </div>
                        <div class="col-12 col-sm-4">
                            <label class="mb-0" for="exampleInputEmail1">Precio Temporada Alta</label>                        
                            <small id="emailHelp" class="form-text text-muted mt-0">$ <?php echo e(number_format($finca->precio_Talta, 0)); ?></small>
                        </div>
                    </div>

                    <h5 class="card-title pt-4">Capacidad y Servicios</h5>

                    <div class="row pt-4">
                        <div class="col-md-12 col-sm-12 col-12">
                            <div class="row justify-content-end">
                                <div class="col-4">
                                    <span><i class="fas fa-users"></i> <?php echo e($finca->max_personas); ?> Huespedes</span>
                                </div>
                                <div class="col-4">
                                    <span><i class="fas fa-bed"></i> <?php echo e($finca->cant_habitaciones); ?> Habitaciones</span>
                                </div>
                                <div class="col-4">
                                    <span><i class="fas fa-bath"></i> <?php echo e($finca->cant_banios); ?> Baños</span>
                                </div>
                            </div>                        
                        </div>
                    </div>                                        

                    <div class="row pt-4">
                        <div class="col-md-12 col-sm-12 col-12">
                            <div class="row">
                                <?php if($finca->sn_jacuzi): ?>
                                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6">
                                    <i class="fas fa-hot-tub"></i> Jacuzi
                                    </div>
                                <?php endif; ?>
                                <?php if($finca->sn_piscina): ?>
                                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6">
                                    <i class="fas fa-swimming-pool"></i> Piscina
                                    </div>
                                <?php endif; ?>
                                <?php if($finca->sn_caballos): ?>
                                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6">
                                    <img src="<?php echo e(asset('img/horse.png')); ?>" class="horse" alt=""> Caballos
                                    </div>
                                <?php endif; ?>
                                <?php if($finca->sn_parqueadero): ?>
                                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6">
                                    <i class="fas fa-car"></i> Parqueadero
                                    </div>
                                <?php endif; ?>
                                <?php if($finca->sn_picnic): ?>
                                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-6">
                                    <i class="fas fa-utensils"></i> Picnic
                                    </div>
                                <?php endif; ?>      
                            </div>                        
                        </div>
                    </div>
               
                    <h5 class="card-title pt-4">Descripcion</h5>

                    <div class="row">
                        <div class="col">
                            <?php echo $finca->descripcion; ?>

                        </div>                        
                    </div>

                    <h5 class="card-title pt-4">Imagenes</h5>

                    <div class="row text-center bg-dark pb-4 ml-1 mr-1 mt-3">
                        <?php $__currentLoopData = $finca->fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-2">
                                <a class="example-image-link thumbnail" href="<?php echo e($foto->archivo); ?>" data-lightbox="example-set" data-title="Click the right half of the image to move forward.">
                                    <div class="card bg-dark text-success mt-4">
                                        <img class="card-img" src="<?php echo e($foto->archivo); ?>" alt="Card image">
                                    </div>  
                                </a>                                                      
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                </div>               
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>