
@extends('layouts.appAdmin')

@section('content')

<h1>Prueba</h1>

@endsection

