@extends('layouts.appAdmin')
@section('content')

<h1 class=" page-header text-center">Prueba Farm Index</h1>

<div class="container">
    <div class="row">
        @include('admin.farm.partial.form')
    </div>
</div>


@endsection

