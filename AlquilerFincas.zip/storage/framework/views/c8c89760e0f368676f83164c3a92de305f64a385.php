<?php $__env->startSection('content'); ?>

<h1 class=" page-header text-center mt-3">Formulario de Creacion</h1>

<div class="container">        
  <div class="row pb-4 justify-content-center">
    <?php echo Form::open(['route' => 'farms.store', 'files' => true]); ?>

      <?php echo $__env->make('admin.farm.partial.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo Form::close(); ?>

  </div>
</div>

<?php $__env->stopSection(); ?>

 <?php $__env->startSection('scripts'); ?>
 
  <script src="<?php echo e(asset('vendor/StringToSlug/jquery.stringToSlug.min.js')); ?>"></script>
  
  <script>
      $(document).ready(function(){
        $('#nombre').stringToSlug({
          callback: function(text){
            $('#slug').val(text);            
          }
        });        
      }); 
  </script>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>