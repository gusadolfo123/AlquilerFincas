<?php $__env->startSection('content'); ?>   
    
        <div class="col-sm-12">
            <h5 class="card-title pt-4 text-center">Imagenes</h5>
            <?php echo Form::open(['route'=> 'farms.upload', 'method' => 'POST', 'files'=>'true', 'id' => 'myDropzone' , 'class' => 'dropzone']); ?>

                
                <?php echo Form::hidden('id', $id, null); ?>

                
                <div class="dz-message" style="height:200px;">
                Arrastre o Seleccione las Imagenes en esta zona
                </div>
                <div class="dropzone-previews"></div>                
            <?php echo Form::close(); ?>

            <button type="submit" id="enviarDatos" class="btn btn-primary mt-4">Enviar</button>

            <a href="<?php echo e(route('farms.edit', $id)); ?>" class="btn btn-primary mt-4">               
                Regresar
            </a>

        </div>
   
<?php $__env->stopSection(); ?>

 <?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('vendor/dropzone/dropzone.js')); ?>"></script>

    <script>
        $(document).ready(function(){
            Dropzone.options.myDropzone = {                
                autoProcessQueue: false,
                uploadMultiple: true,
                parallelUploads: 6,
                maxFiles: 6,
                maxFilesize: 4,
                acceptedFiles: 'image/*',
                addRemoveLinks: true,
                init: function() {
                    dzClosure = this; // Makes sure that 'this' is understood inside the functions below.
                    var submitBtn = document.querySelector("#enviarDatos");
                    
                    submitBtn.addEventListener("click", function(e){
                        e.preventDefault();
                        e.stopPropagation();
                        dzClosure.processQueue();
                    });
                 
                    this.on("success", function(file, responseText) {
                        swal({  type: 'success',
                                title: 'Ok',
                                text: 'Imagenes Subidas Correctamente'
                                });
                        dzClosure.processQueue.bind(dzClosure)                        
                    });
                
                    this.on("complete", function(file) {
                        dzClosure.removeFile(file);
                    });

                   
                }
            }
        });      
    </script>


 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>