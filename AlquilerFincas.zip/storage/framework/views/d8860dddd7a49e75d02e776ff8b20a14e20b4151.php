<?php $__env->startSection('content'); ?>

<div class="container">        
    <div class="row pb-4 justify-content-center">          
        <div class="input-group mb-3 mt-3">
            <div class="input-group-prepend">
                <span class="input-group-text form-control-sm" id="basic-addon1">Nombre</span>
            </div>
            <?php echo Form::text("descripcion", $departamento->descripcion, ['class' => 'form-control form-control-sm', 'id' => 'descripcion']); ?>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>