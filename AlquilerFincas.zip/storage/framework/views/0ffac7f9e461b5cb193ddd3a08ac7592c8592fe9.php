

<div class="card-body" id="contFincas">
    <h5 class="card-title">Resultado Busqueda: [<?php echo e($cantReg); ?>]</h5>

    <? $cont = 0; ?>

    <div class="row">
        <?php $__currentLoopData = $fincas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $finca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6">
                <a href="<?php echo e(route('farm', $finca->slug)); ?>">
                    <div class="card bg-dark text-success mt-4">
                        <img class="card-img" src="<?php echo e($finca->fotos->first()->archivo); ?>" alt="Card image">
                        <div class="card-img-overlay p-0">
                            <h6 class="card-title">
                                <small class="bg-success text-light rounded pl-1 pr-1">Via: <?php echo e($finca->via->descripcion); ?> </small>
                            </h6>
                        </div>
                    </div>  
                </a>                                      
                    <div class="card-footer border-bottom border-success p-0 pl-2 pr-2">
                        <div class="row">
                            <div class="col-6 bg-dark text-light s1 ">
                                <small class="text-light"><i class="fas fa-dollar-sign"></i> <?php echo e(number_format($finca->precio_Tbaja, 0)); ?> Temp. Baja</small>
                            </div>
                            <div class="col-6 bg-primary text-light">
                                <small class="text-light"><i class="fas fa-users"></i> Personas: <?php echo e($finca->max_personas); ?></small>
                            </div>
                        </div>
                    </div>
                
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <hr />

    <div class="row">
        <div class="col-md-12 text-center">
            <?php if(isset($data)): ?>
                <?php echo e($fincas->appends(['p' => 'true'])->links()); ?>

            <?php else: ?>
                <?php echo e($fincas->links()); ?>

            <?php endif; ?>
        </div>
    </div>
    
</div>  