<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" integrity="sha384-hWVjflwFxL6sNzntih27bfxkr27PmbbK/iSvJ+a4+0owXq79v+lsFkW54bOGbiDQ" crossorigin="anonymous">
    <link href="<?php echo e(asset('css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/flexslider.css')); ?>" rel="stylesheet"> 
    <link href="<?php echo e(asset('css/lightbox.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/myStyles.css')); ?>" rel="stylesheet">

</head>
<body>
    <div id="app">
        
        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
            <?php echo e(csrf_field()); ?>

        </form>

        <nav class="navbar navbar-expand-lg navbar-dark bg-success centrar_texto">

            <div class="col-lg-2 col-md-12 col-sm-12 col-xs-12 text-center">
                <a class="navbar-brand" href="#"><?php echo e(config('app.name', 'Alquiler Fincas')); ?></a>
            </div>
            
            <button class="navbar-toggler col-sm-12 color_toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">

                <?php if(auth()->guard()->guest()): ?>
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="<?php echo e(route('login')); ?>">Ingresar</a>
                    </li>
                </ul>   
                <?php else: ?>    
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="<?php echo e(route('Admin.index')); ?>">Inicio <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('farms.index')); ?>">Fincas</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('departments.index')); ?>">Departamentos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('tracks.index')); ?>">Vias</a>
                    </li>   
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('seasons.index')); ?>">Temporadas</a>
                    </li>                 
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('customers.index')); ?>">Clientes</a>
                    </li>                 
                </ul>

                <ul class="navbar-nav ml-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                            Logout
                        </a>
                    </li>
                </ul>  
                <?php endif; ?>
            </div>
        </nav>

        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/jquery-1.12.4.js')); ?>"></script>     
    <!-- FlexSlider -->
    <script src="<?php echo e(asset('js/jquery.flexslider.js')); ?>"></script>  
    <script src="<?php echo e(asset('js/lightbox.js')); ?>"></script>  
    <?php echo $__env->yieldContent('scripts'); ?>

</body>
</html>
