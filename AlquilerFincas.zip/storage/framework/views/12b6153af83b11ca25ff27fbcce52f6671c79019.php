<?php $__env->startSection('content'); ?>

<h1>Prueba</h1>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.appAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>