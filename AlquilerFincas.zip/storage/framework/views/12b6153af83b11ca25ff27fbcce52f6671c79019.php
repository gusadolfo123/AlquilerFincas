<?php $__env->startSection('content'); ?>

    <div class="row-fluid">
        <header>
            <div class=" page-header text-center pt-4">
                <h1>Dashboard AlquilerFincas</h1>
            </div>
        </header>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.appAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>